#include "main_process.h"

ros::Timer timer;
void callback(const ros::TimerEvent&)
{
    int i = timer_callback();
    if(i==1)
    {
       timer.stop();
       ROS_INFO("timer stop");
    }
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "rgbd_mapping");
    initRosApp();
    ros::NodeHandle n;
    timer = n.createTimer(ros::Duration(1.0), callback);
    ros::spin();
    return 0;
}
