#ifndef OCV_TOOLS_H
#define OCV_TOOLS_H

#include <string>
#include <opencv2/opencv.hpp>

std::string type_to_string(cv::Mat m);

#endif // OCV_TOOLS_H
