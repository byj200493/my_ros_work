Kinect v2 calibration:
  Copy "506816242542" folder in "~/catkin_ws/src/iai_kinect2/kinect2_bridge/data"

The number is the Kinect serial shown when launching kinect2_brige:
  ...
  [Freenect2Impl] enumerating devices...
  [Freenect2Impl] 12 usb devices connected
  [Freenect2Impl] found valid Kinect v2 @4:3 with serial 506816242542
  [Freenect2Impl] found 1 devices
  Kinect2 devices found: 
    0: 506816242542 (selected)
  ...
